#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 4
#define VBOX_VERSION_MINOR 2
#define VBOX_VERSION_BUILD 16
#define VBOX_VERSION_STRING_RAW "4.2.16"
#define VBOX_VERSION_STRING "4.2.16_Debian"
#define VBOX_API_VERSION_STRING "4_2"

#endif
