/* This file is auto generated, version 1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#1 SMP Debian 3.10.11-1st1 (2014-02-28)"
#define LINUX_COMPILE_BY "debian-kernel"
#define LINUX_COMPILE_HOST "lists.debian.org"
#define LINUX_COMPILER "gcc version 4.7.2 (Debian 4.7.2-5+steamos1+bsos1) "
