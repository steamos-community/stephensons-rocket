//@line 2 "/usr/src/packages/BUILD/iceweasel-24.3.0esr/debian/vendor.js.in"
pref("general.useragent.compatMode.firefox", true);
//@line 4 "/usr/src/packages/BUILD/iceweasel-24.3.0esr/debian/vendor.js.in"
pref("distribution.searchplugins.defaultLocale", "en-US");
// Forbid application updates
lockPref("app.update.enabled", false);
