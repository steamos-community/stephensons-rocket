static struct {
	const char *short_description;
	const char *description;
} __nv_patches[] = {
{ NULL, NULL } };
