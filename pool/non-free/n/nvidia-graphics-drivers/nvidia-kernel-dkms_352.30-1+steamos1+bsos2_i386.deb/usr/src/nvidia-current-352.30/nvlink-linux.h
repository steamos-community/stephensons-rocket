/* _NVRM_COPYRIGHT_BEGIN_
 *
 * Copyright 2014 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 *
 * _NVRM_COPYRIGHT_END_
 */

#ifndef _NVLINK_LINUX_H_
#define _NVLINK_LINUX_H_

#include "nv-linux.h"

#define NVLINK_DEV_NAME "nvlink"

#define NV_PCI_DEVICE_ID_EBRIDGE_1   0x10EC
#define NV_PCI_DEVICE_ID_EBRIDGE_2   0x10ED

#define NVLINK_NUM_BARS              2
#define NVLINK_BAR_INDEX_REGS1       0
#define NVLINK_BAR_INDEX_REGS2       1

/* this is a general os-specific state structure. */
typedef struct nvlink_linux_state_s {
    /* driver's private state */
    void  *priv;

    struct pci_dev *dev;

    nv_pci_info_t pci_info;

    nv_aperture_t bars[NVLINK_NUM_BARS];

    NvU32  interrupt_line;

} nvlink_linux_state_t;

#endif // _NVLINK_LINUX_H_
