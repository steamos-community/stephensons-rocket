/* _NVRM_COPYRIGHT_BEGIN_
 *
 * Copyright 2015 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 *
 * _NVRM_COPYRIGHT_END_
 */

#ifndef _NV_MODESET_INTERFACE_H_
#define _NV_MODESET_INTERFACE_H_

/*
 * This file defines the interface between the nvidia.ko and
 * nvidia-modeset.ko Linux kernel modules.
 *
 * A minor device file from nvidia.ko's pool is dedicated to
 * nvidia-modeset.ko.  nvidia-modeset.ko registers with nvidia.ko by
 * calling nvidia_register_module() and providing its file operation
 * callback functions.
 *
 * Later, nvidia-modeset.ko calls nvidia.ko's nvidia_get_rm_ops()
 * function to get the RMAPI function pointers which it will need.
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>

#include "nvtypes.h"
#include "nvstatus.h"
#include "nv-misc.h"
#include "nv.h"

/*
 * The RM API entry points which nvidia-modeset.ko should call in nvidia.ko.
 */

typedef struct {
    /*
     * The caller should assign version_string before passing the
     * structure to nvidia.ko, so that a version match can be
     * confirmed: it is not supported to mix nvidia.ko and
     * nvidia-modeset.ko from different releases.
     */
    const char *version_string;

    /*
     * Allocate and free an nvidia_stack_t to pass into
     * nvidia_modeset_rm_ops_t::op().  An nvidia_stack_t must only be
     * used by one thread at a time.
     */
    nvidia_stack_t *(*alloc_stack)(void);
    void (*free_stack)(nvidia_stack_t *sp);

    void (*op)(nvidia_stack_t *sp, void *ops_cmd);
} nvidia_modeset_rm_ops_t;

NV_STATUS nvidia_get_rm_ops(nvidia_modeset_rm_ops_t *rm_ops);

#endif /* _NV_MODESET_INTERFACE_H_ */
