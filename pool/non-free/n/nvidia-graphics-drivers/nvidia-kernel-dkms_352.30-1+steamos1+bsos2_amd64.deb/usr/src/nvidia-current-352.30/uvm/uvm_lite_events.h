/*******************************************************************************
    Copyright (c) 2014 NVIDIA Corporation

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to
    deal in the Software without restriction, including without limitation the
    rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
    sell copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

        The above copyright notice and this permission notice shall be
        included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.

*******************************************************************************/
#ifndef _UVM_LITE_EVENTS_H_
#define _UVM_LITE_EVENTS_H_

#include "uvm_lite.h"
#include "uvm_events.h"

void uvm_init_event_listener_list(UvmProcessRecord *pCurrentProcessRecord);

NV_STATUS uvm_create_event_queue(UvmSessionInfo *pSessionInfo,
                                 UvmEventQueueInfo **ppEventQueueInfo,
                                 NvLength queueSize,
                                 unsigned int notificationCount,
                                 UvmEventTimeStampType timeStampType);

NV_STATUS uvm_get_event_queue(UvmSessionInfo *pSessionInfo,
                              UvmEventQueueInfo **ppEventQueueInfo,
                              NvUPtr eventQueueHandle);

void uvm_remove_event_queue(UvmSessionInfo *pSessionInfo, UvmEventQueueInfo *pEventQueueInfo);

NV_STATUS uvm_map_event_queue(UvmEventQueueInfo *pEventQueueInfo,
                              NvP64  userRODataAddr,
                              NvP64  userRWDataAddr,
                              NvP64  *pReadIndexAddr,
                              NvP64  *pWriteIndexAddr,
                              NvP64  *pQueueBufferAddr,
                              struct vm_area_struct *roVma,
                              struct vm_area_struct *rwVma,
                              struct file *filp);

NV_STATUS uvm_enable_event(UvmEventQueueInfo *pEventQueueInfo,
                           UvmEventType eventType,
                           unsigned pidTarget);

NV_STATUS uvm_disable_event(UvmEventQueueInfo *pEventQueueInfo,
                            UvmEventType eventType,
                            unsigned pidTarget);

NV_STATUS uvm_record_migration_event(UvmProcessRecord *pProcessRecord,
                                     NvU8 direction,
                                     NvU8 srcIndex,
                                     NvU8 dstIndex,
                                     NvU64 address,
                                     NvU64 migratedBytes,
                                     NvU64 beginTimeStamp,
                                     NvU64 endTimeStamp,
                                     NvU64 streamId);

NV_STATUS uvm_record_memory_violation_event(UvmProcessRecord *pProcessRecord,
                                            NvU8 accessType,
                                            NvU64 address,
                                            NvU64 timeStamp,
                                            NvU32 pid,
                                            NvU32 threadId);

NvBool uvm_is_event_enabled(UvmProcessRecord *pProcessRecord,
                            UvmEventType eventType);

NvBool uvm_any_event_notifications_pending(UvmProcessRecord *pProcessRecord);

#endif // _UVM_LITE_EVENTS_H_
