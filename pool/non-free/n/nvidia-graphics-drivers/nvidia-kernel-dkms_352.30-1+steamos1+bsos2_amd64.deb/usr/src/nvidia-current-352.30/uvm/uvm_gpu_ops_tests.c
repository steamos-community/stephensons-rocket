/*******************************************************************************
    Copyright (c) 2014-2015 NVIDIA Corporation

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to
    deal in the Software without restriction, including without limitation the
    rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
    sell copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

        The above copyright notice and this permission notice shall be
        included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
    DEALINGS IN THE SOFTWARE.
*******************************************************************************/

#if defined(DEBUG)

#include "nv_uvm_interface.h"
#include "uvm_gpu_ops_tests.h"
#include "uvm_page_migration.h"
#include "uvm_common.h"
#include "uvm_linux.h"
#include "uvm_lite_region_tracking.h"
#include "uvm_lite.h"
#include "uvm_channel_mgmt.h"

// Helper structure to define a test surface.
typedef struct UvmTestSurface_t
{
    UvmGpuPointer       gpuPointer;
    void                *cpuPointer;
    NvU64               size;
    unsigned            aperture;
} UvmTestSurface;

// Helper structure to define a copy operation.
typedef struct UvmTestCopyOp_t
{
    UvmGpuPointer       dstGpuPointer;
    UvmGpuPointer       srcGpuPointer;
    unsigned            dstAperture;
    unsigned            srcAperture;
    NvU64               surfSize;
    unsigned            copyFlags;    // SRC|DST PHYSICAL|VIRUAL
} UvmTestCopyOp;

void gpuOpsSampleTest(UvmGpuUuid  * pUuidStruct)
{
    UVM_DBG_PRINT_UUID("Entering", pUuidStruct);
    return;
}

void pageMigrationTest(UvmGpuUuid  * pUuidStruct)
{
    NV_STATUS status;

    // arbitrarily choose that our region size will be 16KB
    const unsigned REGION_SIZE = 0x4000;
    const unsigned SEMA_SIZE =   4*1024;
    uvmGpuSessionHandle hSession;
    uvmGpuAddressSpaceHandle hVaSpace;
    uvmGpuChannelHandle hChannel;
    UvmGpuChannelPointers channelPointers;
    unsigned copyEngineClassNumber;
    uvmGpuCopyEngineHandle hCopyEngine;
    void * pbCpuPointer;
    UvmGpuPointer pbGpuPointer;
    UvmGpuPointer semaGpuPointer;
    void * semaCpuPointer;
    void * pbPutPointer;

    UvmGpuPointer fbRegionGpuPointer;
    void * fbRegionCpuPointer;
    void *pbEnd;
    UvmGpuPointer sysmemRegionGpuPointer;
    void * sysmemRegionCpuPointer;
    unsigned flags = 0;
    unsigned word;
    UvmCopyOps ceOps = {0};
    NvLength numMethods;
    unsigned semaVal;
    unsigned long long uuidMsb = 0;
    unsigned long long uuidLsb = 0;
    UvmGpuAllocInfo allocInfo;

    UVM_DBG_PRINT_UUID("Entering", pUuidStruct);
    memset(&allocInfo, 0, sizeof(allocInfo));

    //
    // allocate all resources necessary to utilize a CE:
    // 1) allocate cli/dev/subdev
    // 2) allocate channel from cli/dev VA space
    // 3) allocate OBJCE
    // 4) allocate PB
    //
    status = nvUvmInterfaceSessionCreate(&hSession);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not create a session.", status);
        return;
    }

    memcpy(&uuidMsb, &pUuidStruct->uuid[0], (UVM_UUID_LEN >> 1));
    memcpy(&uuidLsb, &pUuidStruct->uuid[8], (UVM_UUID_LEN >> 1));


    status = nvUvmInterfaceAddressSpaceCreateMirrored(hSession,
                                                      uuidMsb,
                                                      uuidLsb,
                                                     &hVaSpace);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not create an address space.", status);
        return;
    }

    status = nvUvmInterfaceChannelAllocate(hVaSpace, &hChannel,
                                          &channelPointers);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not allocate a channel.", status);
        return;
    }

    status = nvUvmInterfaceCopyEngineAllocate(hChannel, 1,
                                             &copyEngineClassNumber,
                                             &hCopyEngine);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not allocate OBJCE.", status);
        return;
    }

    // allocate semaphore page
    status = nvUvmInterfaceMemoryAllocSys(hVaSpace, SEMA_SIZE,
                                        &semaGpuPointer, NULL);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not allocate GPU memory for PB.", status);
        return;
    }

    status = nvUvmInterfaceMemoryCpuMap(hVaSpace, semaGpuPointer,
                                        SEMA_SIZE, &semaCpuPointer,
                                        UVM_PAGE_SIZE_DEFAULT);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not map PB to CPU VA.", status);
        return;
    }

    // Push Buffer
    status = nvUvmInterfaceMemoryAllocSys(hVaSpace, REGION_SIZE,
                                         &pbGpuPointer, NULL);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not allocate GPU memory for PB.", status);
        return;
    }
    // Map Push Buffer
    status = nvUvmInterfaceMemoryCpuMap(hVaSpace, pbGpuPointer,
                                        REGION_SIZE, &pbCpuPointer,
                                        UVM_PAGE_SIZE_DEFAULT);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not map PB to CPU VA.", status);
        return;
    }

    // allocate CPU accessible memory on FB that we can copy to/from for testing
    status = nvUvmInterfaceMemoryAllocFB(hVaSpace, REGION_SIZE,
                                        &fbRegionGpuPointer, &allocInfo);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not allocate FB region for testing.",
                                status);
        return;
    }

    status = nvUvmInterfaceMemoryCpuMap(hVaSpace, fbRegionGpuPointer,
                                        REGION_SIZE, &fbRegionCpuPointer,
                                        UVM_PAGE_SIZE_DEFAULT);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not map GPU memory to CPU VA.",
                                status);
        return;
    }

    //
    // allocate CPU accessible memory on SYSMEM that we can copy to/from for
    // testing
    //
    status = nvUvmInterfaceMemoryAllocSys(hVaSpace, REGION_SIZE,
                                         &sysmemRegionGpuPointer, NULL);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not allocate SYSMEM region for testing.",
                                status);
        return;
    }

    status = nvUvmInterfaceMemoryCpuMap(hVaSpace, sysmemRegionGpuPointer,
                                        REGION_SIZE,
                                       &sysmemRegionCpuPointer,
                                        UVM_PAGE_SIZE_DEFAULT);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not map SYSYMEM to CPU VA.",
                                status);
        return;
    }

    // setup CE Ops
    NvUvmHalInit(copyEngineClassNumber, 0x0000A06F, &ceOps);

    //setup to copy from SYSMEM to FB
    memset(fbRegionCpuPointer, 0xdeadbeef, REGION_SIZE);
    memset(sysmemRegionCpuPointer, 0xbad0cafe, REGION_SIZE);
    memset(semaCpuPointer, 0, SEMA_SIZE);


    // lets insert one sema and check for release
    pbPutPointer = pbCpuPointer;
    pbEnd = pbPutPointer + (REGION_SIZE / sizeof(unsigned));
    numMethods = ceOps.semaphoreRelease((unsigned **)&pbPutPointer,
                                        pbEnd,
                                        semaGpuPointer, 0xFACEFEED);

    // write the GP entry
    ceOps.writeGpEntry(channelPointers.gpFifoEntries, 0, pbGpuPointer,
                       numMethods);

    // launch the sema release
    NvUvmChannelWriteGpPut(channelPointers.GPPut, 1);

    // check if we get back the sempahore
    while(1)
        {
        semaVal = 0;
                semaVal = *(unsigned *)semaCpuPointer;
        UVM_DBG_PRINT("SemaVal:= 0x%x\n", semaVal);
        if(semaVal == 0xFACEFEED)
            break;
        }


    pbPutPointer += numMethods;
    pbGpuPointer += numMethods;
    pbEnd = pbPutPointer + (REGION_SIZE / sizeof(unsigned));

    // push methods to do a copy
    numMethods = ceOps.launchDma((unsigned **)&pbPutPointer,
                    pbEnd,
                    sysmemRegionGpuPointer, 2,
                    fbRegionGpuPointer, 0,
                    REGION_SIZE, flags);

    // write the GP entry
    ceOps.writeGpEntry(channelPointers.gpFifoEntries, 1, pbGpuPointer,
                       numMethods);

    // launch the copy
    NvUvmChannelWriteGpPut(channelPointers.GPPut, 2);


    // check that the pattern copied to FB is the same as the pattern in SYSMEM
    for (word = 0; word < REGION_SIZE / sizeof(unsigned); word ++)
    {
        UVM_INFO_PRINT("INFO: checking 0x%X == 0x%X ?\n",
                       ((unsigned*)fbRegionCpuPointer)[word],
                       ((unsigned*)sysmemRegionCpuPointer)[word]);
        if (((unsigned*)fbRegionCpuPointer)[word] !=
            ((unsigned*)sysmemRegionCpuPointer)[word])
        {
            UVM_DBG_PRINT_RL("ERROR: copy failed. FB region = 0x%X,"
                             " SYSMEM region = 0x%X\n",
                             ((unsigned*)fbRegionCpuPointer)[word],
                             ((unsigned*)sysmemRegionCpuPointer)[word]);

            nvUvmInterfaceSessionDestroy(hSession);
            return;
        }
    }
    nvUvmInterfaceChannelDestroy(hChannel);
    nvUvmInterfaceAddressSpaceDestroy(hVaSpace);
    nvUvmInterfaceSessionDestroy(hSession);

    UVM_DBG_PRINT("INFO: Passed\n");
}

//
// Test copying from sysmem to fb.
//
void channelMgmtApiBasicMigrationTest(UvmGpuUuid *pGpuUuidStruct)
{
    NV_STATUS status;
    UvmTracker     tracker;
    UvmTrackerItem trackerItem;
    // arbitrarily choose that our region size will be 16KB
    const unsigned REGION_SIZE = 0x4000;

    UvmChannelManager *channelManager = NULL;
    UvmPushbuffer     *pushbuffer     = NULL;

    UvmChannelPool *channelPool = NULL;

    UvmGpuPointer fbRegionGpuPointer     = 0;
    void         *fbRegionCpuPointer     = NULL;
    UvmGpuPointer sysmemRegionGpuPointer = 0;
    void         *sysmemRegionCpuPointer = NULL;

    NvLength       numBytes     = 0;
    unsigned       word         = 0;
    UvmGpuAllocInfo allocInfo;
    void          *pbEnd        = NULL;
    UvmTracker     *tempTracker = NULL;


    UVM_DBG_PRINT_UUID("Entering",
                       pGpuUuidStruct);

    memset(&allocInfo, 0, sizeof(allocInfo));
    status = uvm_initialize_channel_mgmt_api();
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("could not initialize channel mgmt api.",
                                status);
        goto cleanup;
    }

    status = uvm_create_channel_manager(pGpuUuidStruct, &channelManager);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not allocate UvmManager.",
                                status);
        goto cleanup;
    }

    status = uvm_get_pushbuffer(channelManager, &pushbuffer);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not get push buffer.",
                                status);
        goto cleanup;
    }

    channelPool = &channelManager->channelPool;

    // allocate CPU accessible memory on FB that we can copy to/from for testing
    status = nvUvmInterfaceMemoryAllocFB(channelPool->hVaSpace,
                                         REGION_SIZE,
                                         &fbRegionGpuPointer,
                                         &allocInfo);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not allocate FB region for testing.",
                                status);
        goto cleanup;
    }

    status = nvUvmInterfaceMemoryCpuMap(channelPool->hVaSpace,
                                        fbRegionGpuPointer,
                                        REGION_SIZE,
                                        &fbRegionCpuPointer,
                                        UVM_PAGE_SIZE_DEFAULT);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not map GPU memory to CPU VA.", status);
        goto cleanup;
    }

    //
    // allocate CPU accessible memory on SYSMEM that we can copy to/from for
    // testing
    //
    status = nvUvmInterfaceMemoryAllocSys(channelPool->hVaSpace,
                                          REGION_SIZE,
                                          &sysmemRegionGpuPointer,
                                          NULL);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not allocate SYSMEM region for testing",
                                status);
        goto cleanup;
    }

    status = nvUvmInterfaceMemoryCpuMap(channelPool->hVaSpace,
                                        sysmemRegionGpuPointer,
                                        REGION_SIZE,
                                        &sysmemRegionCpuPointer,
                                        UVM_PAGE_SIZE_DEFAULT);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not map SYSYMEM to CPU VA.", status);
        goto cleanup;
    }

    //setup to copy from SYSMEM to FB
    memset(fbRegionCpuPointer, 0xFF, REGION_SIZE);
    memset(sysmemRegionCpuPointer, 0x1, REGION_SIZE);

    UVM_INFO_PRINT("\n"
                   "INFO: fb     cpu: 0x%x\n"
                   "INFO: sysmem cpu: 0x%x\n",
                   *((unsigned*)fbRegionCpuPointer),
                   *((unsigned*)sysmemRegionCpuPointer));


    //
    // test migration
    //

    // Initialize the tracker on stack.
    uvm_init_tracker(&tracker);
    // Allocate a temporary tracker to merge all the submit info.
    tempTracker = uvm_allocate_tracker();
    status = uvm_grow_tracker(tempTracker, 1);
    if (status != NV_OK)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not grow temp tracker",
                                status);
        goto cleanup;
    }

    // Reserve space for acquires in the pushbuffer.
    uvm_reserve_acquire_space(channelManager, pushbuffer, &tracker);

    pbEnd = (void *)((NvU64)pushbuffer->cpuBegin +
                     UVM_PUSHBUFFER_RESERVATION_SIZE);
    // Insert methods into the pb to copy sysmem to fb
    UVM_PUSH_METHOD(numBytes,
                    pushbuffer,
                    pushbuffer->channel->ceOps.launchDma,
                    sysmemRegionGpuPointer,
                    NV_UVM_COPY_SRC_LOCATION_SYSMEM,
                    fbRegionGpuPointer,
                    NV_UVM_COPY_DST_LOCATION_FB,
                    REGION_SIZE,
                    NV_UVM_COPY_SRC_TYPE_VIRTUAL |
                    NV_UVM_COPY_DST_TYPE_VIRTUAL);
    if (!numBytes)
    {
        status = NV_ERR_NO_MEMORY;
        UVM_ERR_PRINT_NV_STATUS("Could not push method pb.", status);
        goto cleanup;
    }

    status = uvm_submit_pushbuffer(channelManager,
                                   pushbuffer,
                                   &tracker,
                                   &trackerItem);
    if (status != NV_OK)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not submit pushbuffer", status);
        goto cleanup;
    }
    // Merge the trackerItem into the original tracker
    status = uvm_merge_tracker_item(tempTracker, &trackerItem);
    if (status != NV_OK)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not merge tracker item", status);
        goto cleanup;
    }
    // Move the tempTracker into original tracker.
    uvm_move_tracker(&tracker, tempTracker);
    // A shrink on tempTracker should return 0
    if (uvm_shrink_tracker(tempTracker))
    {
        UVM_ERR_PRINT_NV_STATUS("temp tracker state not as expected.", status);
        goto cleanup;
    }

    status = uvm_wait_for_tracker(&tracker);
    if (status != NV_OK)
    {
        UVM_ERR_PRINT_NV_STATUS("wait on tracker failed!!", status);
        goto cleanup;
    }

    // check that the pattern copied to FB is the same as the pattern in SYSMEM
    for (word = 0; word < REGION_SIZE / sizeof(unsigned); word ++)
    {
        if (((unsigned*)fbRegionCpuPointer)[word] !=
            ((unsigned*)sysmemRegionCpuPointer)[word])
        {
            UVM_ERR_PRINT("ERROR: copy failed. FB region = 0x%X,"
                          " SYSMEM region = 0x%X\n",
                          ((unsigned*)fbRegionCpuPointer)[word],
                          ((unsigned*)sysmemRegionCpuPointer)[word]);
            break;
        }
    }

cleanup:
    if (sysmemRegionCpuPointer)
        nvUvmInterfaceMemoryCpuUnMap(channelPool->hVaSpace,
                                     sysmemRegionCpuPointer);

    if (sysmemRegionGpuPointer)
        nvUvmInterfaceMemoryFree(channelPool->hVaSpace,
                                 sysmemRegionGpuPointer);

    if (fbRegionCpuPointer)
        nvUvmInterfaceMemoryCpuUnMap(channelPool->hVaSpace,
                                     fbRegionCpuPointer);

    if (fbRegionGpuPointer)
        nvUvmInterfaceMemoryFree(channelPool->hVaSpace,
                                 fbRegionGpuPointer);

    uvm_reset_tracker(&tracker);
    uvm_shrink_tracker(&tracker);
    uvm_free_tracker(tempTracker);

    if (channelManager)
    {
        uvm_destroy_channel_manager(channelManager);
    }

    uvm_deinitialize_channel_mgmt_api();
}

// Helper function to launch a copy using a channel manager and a tracker.
static NV_STATUS
_channel_mgmt_apitest_copy_op(UvmChannelManager *channelManager,
                              UvmTracker *tracker,
                              UvmTestCopyOp *copyOp)
{
    UvmTracker          *tempTracker;
    UvmTrackerItem      trackerItem;
    NV_STATUS           status;
    UvmPushbuffer       *pushbuffer = NULL;
    NvU32               ret;

    // Make space in the temporary tracker.
    tempTracker = uvm_allocate_tracker();
    if (!tempTracker)
    {
        status = NV_ERR_NO_MEMORY;
        goto cleanup;
    }
    status = uvm_grow_tracker(tempTracker, 1);
    if (status != NV_OK)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not get grow temp tracker.",
                                status);
            goto cleanup;
    }

    // Get pushbuffer for copy.
    status = uvm_get_pushbuffer(channelManager, &pushbuffer);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not get pushbuffer for copy.",
                                status);
        goto cleanup;
    }
    uvm_reserve_acquire_space(channelManager, pushbuffer, tracker);

    // push methods to do a copy
    UVM_PUSH_METHOD(ret, pushbuffer,
                    pushbuffer->channel->ceOps.launchDma,
                    copyOp->srcGpuPointer, copyOp->srcAperture,
                    copyOp->dstGpuPointer, copyOp->dstAperture,
                    copyOp->surfSize,
                    copyOp->copyFlags);
    if (!ret)
    {
        status = NV_ERR_NO_MEMORY;
        UVM_ERR_PRINT_NV_STATUS("Could not push method to pb.", status);
        goto cleanup;
    }

    // submit pushbuffer
    status = uvm_submit_pushbuffer(channelManager, pushbuffer,
                                   tracker, &trackerItem);
    if (status != NV_OK)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not submit 1st pushbuffer.", status);
        goto cleanup;
    }
    // Merge the item into the temp tracker.
    status = uvm_merge_tracker_item(tempTracker, &trackerItem);
    if (status != NV_OK)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not merge tracker item.", status);
        goto cleanup;
    }
    // Move the temp tracker into the primary tracker
    uvm_move_tracker(tracker, tempTracker);

cleanup:
    uvm_free_tracker(tempTracker);
    if (pushbuffer && status != NV_OK)
        uvm_cancel_pushbuffer(channelManager, pushbuffer);
    return status;
}

#define CHANNEL_MGMT_API_TEST_SURFACES 3
//
// Simple Pushbuffer Sanity Test
//
//   Summary: Allocate Surface 0, 1 and 2 in sysmem, FB and sysmem respectively.
//            Copy data from 0 to 1 and then from 1 to 2.
//            Wait on tracker for the last operation to complete.
//            Verify data.
//
void channelMgmtApiPushbufferSimpleSanityTest(UvmGpuUuid *pGpuUuidStruct)
{
    NV_STATUS status;
    unsigned index;

    // arbitrarily choose that our region size will be 32 * 4KB
    const unsigned REGION_SIZE = 0x1000 * 32;
    const unsigned loops = 2;
    const unsigned surfaces = CHANNEL_MGMT_API_TEST_SURFACES;

    UvmTracker tracker;   // The primary tracker for the set of operations.
    UvmChannelManager *channelManager = NULL;

    UvmChannelPool *channelPool = NULL;

    uvmGpuAddressSpaceHandle hVaSpace = 0;

    // TODO: start using the UvmTestSurface to better manage the below.
    UvmGpuPointer surfGpuPointer[CHANNEL_MGMT_API_TEST_SURFACES] = {0};
    void*         surfCpuPointer[CHANNEL_MGMT_API_TEST_SURFACES] = {0};
    unsigned word = 0;

    UVM_DBG_PRINT_UUID("Entering", pGpuUuidStruct);

    status = uvm_initialize_channel_mgmt_api();
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("could not initialize channel mgmt api.",
                                status);
        goto cleanup;
    }

    status = uvm_create_channel_manager(pGpuUuidStruct, &channelManager);
    if (NV_OK != status)
    {
        UVM_ERR_PRINT_NV_STATUS("Could not allocate Channel Manager.",
                                status);
        goto cleanup;
    }

    channelPool = &channelManager->channelPool;
    hVaSpace = channelPool->hVaSpace;

    for (index = 0; index < surfaces; index++)
    {
        // odd surface on FB
        if (index % 2)
        {
            // Allocate surface on FB
            status = nvUvmInterfaceMemoryAllocFB(hVaSpace, REGION_SIZE,
                                                &surfGpuPointer[index], NULL);
            if (NV_OK != status)
            {
                UVM_ERR_PRINT_NV_STATUS("Could not allocate surface in FB.",
                                        status);
                goto cleanup;
            }
        }
        else
        {
            status = nvUvmInterfaceMemoryAllocSys(hVaSpace, REGION_SIZE,
                                                  &surfGpuPointer[index], NULL);
            if (NV_OK != status)
            {
                UVM_ERR_PRINT_NV_STATUS("Could not allocate surface in sysmem.",
                                        status);
                goto cleanup;
            }
        }
        status = nvUvmInterfaceMemoryCpuMap(hVaSpace,
                                            surfGpuPointer[index],
                                            REGION_SIZE,
                                            &surfCpuPointer[index],
                                            UVM_PAGE_SIZE_DEFAULT);
        if (NV_OK != status)
        {
            UVM_ERR_PRINT_NV_STATUS("Could not map surface to CPU VA.",
                                    status);
            goto cleanup;
        }

    UVM_INFO_PRINT("Surface %d pointers: "
                   "cpu pointer: 0x%p "
                   "gpu pointer: 0x%llx\n",
                   index,
                   surfCpuPointer[index],
                   surfGpuPointer[index]);
    }

    //
    // Test migration
    // Initialize the primary tacker. (no items for now)
    //
    uvm_init_tracker(&tracker);
    for (index = 0; index < loops; ++index)
    {
        UvmTestCopyOp copyOp = {0};
        memset(surfCpuPointer[0], (index+1), REGION_SIZE);

        UVM_INFO_PRINT("%dth loop start: "
                "Surface 0 cpu: 0x%X "
                "Surface 1 cpu: 0x%X "
                "Surface 2 cpu: 0x%X\n",
                index,
                *((unsigned*)(surfCpuPointer[0])),
                *((unsigned*)(surfCpuPointer[1])),
                *((unsigned*)(surfCpuPointer[2])));

        // Setup first copy operation
        copyOp.dstGpuPointer = surfGpuPointer[1];
        copyOp.srcGpuPointer = surfGpuPointer[0];
        copyOp.dstAperture = NV_UVM_COPY_DST_LOCATION_FB;
        copyOp.srcAperture = NV_UVM_COPY_SRC_LOCATION_SYSMEM;
        copyOp.surfSize = REGION_SIZE;
        copyOp.copyFlags = NV_UVM_COPY_SRC_TYPE_VIRTUAL |
                           NV_UVM_COPY_DST_TYPE_VIRTUAL;

        // Launch the operation.
        status = _channel_mgmt_apitest_copy_op(channelManager,
                                               &tracker,
                                               &copyOp);
        if (NV_OK != status)
        {
            UVM_ERR_PRINT_NV_STATUS("Could not launch the first copy.",
                    status);
            goto cleanup;
        }

        // Setup second copy operation
        copyOp.dstGpuPointer = surfGpuPointer[2];
        copyOp.srcGpuPointer = surfGpuPointer[1];
        copyOp.dstAperture = NV_UVM_COPY_DST_LOCATION_SYSMEM;
        copyOp.srcAperture = NV_UVM_COPY_SRC_LOCATION_FB;
        copyOp.surfSize = REGION_SIZE;
        copyOp.copyFlags = NV_UVM_COPY_SRC_TYPE_VIRTUAL |
                           NV_UVM_COPY_DST_TYPE_VIRTUAL;

        // Launch the operation.
        status = _channel_mgmt_apitest_copy_op(channelManager,
                                               &tracker,
                                               &copyOp);
        if (NV_OK != status)
        {
            UVM_ERR_PRINT_NV_STATUS("Could not launch the second copy.",
                                    status);
            goto cleanup;
        }

        // We have launched both copies. Now wait for tracker to complete.
        uvm_wait_for_tracker(&tracker);

        // Check the pattern is copied to last surface
        for (word = 0; word < REGION_SIZE / sizeof(unsigned); word++)
        {
            if (((unsigned*)surfCpuPointer[0])[word] !=
                    ((unsigned*)surfCpuPointer[2])[word])
            {
                UVM_ERR_PRINT("ERROR: Copy failed. src region = 0x%X,"
                        " dst region = 0x%X\n",
                        ((unsigned*)surfCpuPointer[0])[word],
                        ((unsigned*)surfCpuPointer[2])[word]);
                break;
            }
        }
        UVM_INFO_PRINT("%dth loop End: "
                "Surface 0 cpu: 0x%X "
                "Surface 1 cpu: 0x%X "
                "Surface 2 cpu: 0x%X\n",
                index,
                *((unsigned*)(surfCpuPointer[0])),
                *((unsigned*)(surfCpuPointer[1])),
                *((unsigned*)(surfCpuPointer[2])));
    }

cleanup:
    for (index = 0; index < surfaces; index++)
    {
        if (surfCpuPointer[index])
            nvUvmInterfaceMemoryCpuUnMap(hVaSpace, surfCpuPointer[index]);

        if (surfGpuPointer[index])
            nvUvmInterfaceMemoryFree(hVaSpace, surfGpuPointer[index]);
    }

    // Free the primary tracker off any tracker items it may have accumulated.
    uvm_reset_tracker(&tracker);
    uvm_shrink_tracker(&tracker);
    if (channelManager)
        uvm_destroy_channel_manager(channelManager);

    uvm_deinitialize_channel_mgmt_api();
}

void _destroy_dummy_region(UvmCommitRecord * commit)
{
    const unsigned long long REGION_NUMBER = 0x1000;
    // The commit is supposed to be a fake commit
    // just check that the pointer contain the magick number
    if (commit > (UvmCommitRecord *) REGION_NUMBER)
        UVM_ERR_PRINT_NV_STATUS("Ask to destroy an invalid commit",
                                NV_ERR_INVALID_ARGUMENT);
}

//
// Simple Region Tracking Sanity Test
//
//   1. Create a region tracking tree
//
//   2. Add a regions in the tree
//
//   3. Check the regions
//
//   4. Destroy the region tracking tree
//
void regionTrackerSanityTest(void)
{
    const unsigned long long REGION_NUMBER = 0x1000;
    const unsigned long long REGION_SIZE = 0x1000;

    NV_STATUS status;
    struct vm_area_struct vma;
    UvmRegionTracker *region_tracker = NULL;
    unsigned long long region = 0;
    unsigned long long offset = 0;

    // Create a fake vma
    vma.vm_start = 0x0;
    vma.vm_end = (unsigned long)(REGION_NUMBER * REGION_SIZE);

    region_tracker = uvm_create_region_tracker(&vma);

    if (!region_tracker)
    {
        status = NV_ERR_NO_MEMORY;
        UVM_ERR_PRINT_NV_STATUS("Could not create a region tracking tree.",
                                status);
        goto cleanup;
    }

    for (region = 0; region < REGION_NUMBER; region++)
    {
      unsigned long long fakeRegionStart = region * REGION_SIZE;
      unsigned long long fakeRegionEnd = (region + 1) * REGION_SIZE;

      // Create a fake commit record pointer that is only an incremental
      // counter
      UvmCommitRecord * fakeCommitRecord = (UvmCommitRecord *) (region);

      uvm_track_region(region_tracker,
                       fakeRegionStart,
                       fakeRegionEnd, NULL,
                       fakeCommitRecord);
    }

    // Check that everything is correct
    for (region = 0; region < REGION_NUMBER; region++)
    {
        unsigned long long fakeRegionStart = region * REGION_SIZE;
        UvmCommitRecord * fakeCommitRecordExpected = (UvmCommitRecord *) (region);
        UvmCommitRecord *commitToCheck;
        for (offset = 0; offset < REGION_SIZE; offset++)
        {
            status = uvm_get_owner_from_address(region_tracker,
                                                fakeRegionStart + offset,
                                                &commitToCheck);
            if (NV_OK != status)
            {
                UVM_ERR_PRINT_NV_STATUS("Could not get information for the address.",
                                        status);
                goto cleanup;
            }
            // The fake commit record is supposed to be an incremental counter
            // Just check if the expected value of the counter is the one store
            // in the region tracking tree
            if (commitToCheck != fakeCommitRecordExpected)
            {
                status = NV_ERR_INVALID_ARGUMENT;
                UVM_ERR_PRINT_NV_STATUS("Invalid owner in the region tracking tree.",
                                        status);
            }
        }
    }

cleanup:
    uvm_destroy_region_tracker(region_tracker, _destroy_dummy_region);
}

#endif
