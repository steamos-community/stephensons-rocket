/* _NVRM_COPYRIGHT_BEGIN_
 *
 * Copyright 2013 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 *
 * _NVRM_COPYRIGHT_END_
 */

//
// This file provides the interface that RM exposes to UVM.
//

#ifndef _NV_UVM_INTERFACE_H_
#define _NV_UVM_INTERFACE_H_

// Forward references, to break circular header file dependencies:
struct UvmOpsUvmEvents;

//
// TODO (bug 1359805): This should all be greatly simplified. It is still
// carrying along a lot of baggage from when RM depended on UVM. Now that
// direction is reversed: RM is independent, and UVM depends on RM.
//
#if defined(NVIDIA_UVM_ENABLED)

// We are in the UVM build system, for a Linux target.
#include "uvmtypes.h"
#include "uvm_linux.h"

#else

// We are in the RM build system, for a Linux target:
#include "nv-linux.h"

#endif // NVIDIA_UVM_ENABLED

#include "nvgputypes.h"
#include "rmretval.h"
#include "nv_uvm_types.h"

/*******************************************************************************
    nvUvmInterfaceSessionCreate

    TODO: Creates session object.  All allocations are tied to the session.

    Error codes:
      NV_ERR_GENERIC
      NV_ERR_NO_MEMORY
*/
NV_STATUS nvUvmInterfaceSessionCreate(uvmGpuSessionHandle *session);

/*******************************************************************************
    nvUvmInterfaceSessionDestroy

    Destroys a session object.  All allocations are tied to the session will
    be destroyed.

    Error codes:
      NV_ERR_GENERIC
      NV_ERR_NO_MEMORY
*/
NV_STATUS nvUvmInterfaceSessionDestroy(uvmGpuSessionHandle session);

/*******************************************************************************
    nvUvmInterfaceAddressSpaceCreate

    This function creates an address space.
    This virtual address space is created on the GPU specified
    by the gpuUuid.


    Error codes:
      NV_ERR_GENERIC
      NV_ERR_NO_MEMORY
*/
NV_STATUS nvUvmInterfaceAddressSpaceCreate(uvmGpuSessionHandle session,
                                            unsigned long long uuidMsb,
                                            unsigned long long uuidLsb,
                                            uvmGpuAddressSpaceHandle *vaSpace,
                                            unsigned long long vaBase,
                                            unsigned long long vaSize);

/*******************************************************************************
    nvUvmInterfaceAddressSpaceCreateMirrored

    This function will associate a privileged address space which mirrors the
    address space associated to the provided PID.

    This address space will have a 128MB carveout. All allocations will
    automatically be limited to this carve out.

    This function will be meaningful and needed only for Kepler.

    Error codes:
      NV_ERR_GENERIC
      NV_ERR_NO_MEMORY
*/
NV_STATUS nvUvmInterfaceAddressSpaceCreateMirrored(uvmGpuSessionHandle session,
                                             unsigned long long uuidMsb,
                                             unsigned long long uuidLsb,
                                             uvmGpuAddressSpaceHandle *vaSpace);

/*******************************************************************************
    nvUvmInterfaceAddressSpaceDestroy

    Destroys an address space that was previously created via
    nvUvmInterfaceAddressSpaceCreate or
    nvUvmInterfaceAddressSpaceCreateMirrored.
*/

void nvUvmInterfaceAddressSpaceDestroy(uvmGpuAddressSpaceHandle vaSpace);

/*******************************************************************************
    nvUvmInterfaceMemoryAllocFB

    This function will allocate video memory and provide a mapped Gpu
    virtual address to this allocation. It also returns the Gpu physical
    offset if contiguous allocations are requested.

    This function will allocate a minimum page size if the length provided is 0
    and will return a unique GPU virtual address.

    The default page size will be the small page size (as returned by query
    caps). The Alignment will also be enforced to small page size(64K/128K).
 
    Arguments:
        vaSpace[IN]          - Pointer to vaSpace object
        length [IN]          - Length of the allocation
        gpuPointer[OUT]      - GPU VA mapping
        allocInfo[IN/OUT]    - Pointer to allocation info structure which
                               contains below given fields
 
        allocInfo Members: 
        rangeBegin[IN]             - Allocation will be made between rangeBegin
        rangeEnd[IN]                 and rangeEnd(both inclusive). Default will be
                                     no-range limitation.
        gpuPhysOffset[OUT]         - Physical offset of allocation returned only
                                     if contiguous allocation is requested. 
        bContiguousPhysAlloc[IN]   - Flag to request contiguous allocation. Default
                                     will follow the vidHeapControl default policy.
        bHandleProvided [IN]       - Flag to signify that the client has provided 
                                     the handle for phys allocation.
        hPhysHandle[IN/OUT]        - The handle will be used in allocation if provided.
                                     If not provided; allocator will return the handle
                                     it used eventually.
    Error codes:
        NV_ERR_INVALID_ARGUMENT  
        NV_ERR_NO_MEMORY              - Not enough physical memory to service
                                        allocation request with provided constraints
        NV_ERR_INSUFFICIENT_RESOURCES - Not enough available resources to satisfy allocation request
        NV_ERR_INVALID_OWNER          - Target memory not accessible by specified owner
        NV_ERR_NOT_SUPPORTED          - Operation not supported on broken FB
 
*/
NV_STATUS nvUvmInterfaceMemoryAllocFB(uvmGpuAddressSpaceHandle vaSpace,
                                      NvLength length,
                                      UvmGpuPointer * gpuPointer,
                                      UvmGpuAllocInfo * allocInfo);

/*******************************************************************************
    nvUvmInterfaceMemoryAllocGpuVa

    This function will allocate Virtual memory on the gPU.

    This function will allocate a minimum page size if the length provided is 0
    and will return a unique GPU virtual address.

    The default page size will be the small page size (as returned by query
    caps). The Alignment will also be enforced to small page size(64K/128K).
 
    Arguments:
        vaSpace[IN]          - Pointer to vaSpace object
        length [IN]          - Length of the allocation
        gpuPointer[OUT]      - GPU VA offset
        allocInfo[IN/OUT]    - Pointer to allocation info structure which
                               contains below given fields
 
        allocInfo Members: 
        vaStart[IN]               - Hint to allocate at this start address. Must be aligned to page size.
        bFixedAddressAllocate[IN] - Set this flag for fixed address allocations starting at vaStart
        pageSize[OUT]             - Supported GPU Page size to use for this VA allocation.
                                     
    Error codes:
        NV_ERR_INVALID_ARGUMENT  
        NV_ERR_NO_MEMORY              - Not enough physical memory to service
                                        allocation request with provided constraints
        NV_ERR_INSUFFICIENT_RESOURCES - Not enough available resources to satisfy allocation request
        NV_ERR_NOT_SUPPORTED          - Operation not supported on broken FB
 
*/
NV_STATUS nvUvmInterfaceMemoryAllocGpuVa(uvmGpuAddressSpaceHandle vaSpace,
                                         NvLength length,
                                         UvmGpuPointer * gpuPointer,
                                         UvmGpuVaAllocInfo * allocInfo);

/*******************************************************************************
    nvUvmInterfaceMemoryAllocGpuPa

    This function will *ONLY* allocate contiguous physical video memory. 
    There is no mapping provided to the physical memory allocated.
    This is primarily used for testing till the MM module comes up. This will be 
    the API used to allocate physical VIDMEM that the UVM driver will manage for
    cuda applications.

    
    Arguments:
        vaSpace[IN]          - Pointer to vaSpace object
        length [IN]          - Length of the allocation
        gpuPointer[OUT]      - GPU FB offset
        allocInfo[IN/OUT]    - Pointer to allocation info structure which
                               contains below given fields
 
        allocInfo Members: 
        rangeBegin[IN]             - Allocation will be made between rangeBegin
        rangeEnd[IN]                 and rangeEnd(both inclusive). Default will be
                                     no-range limitation.
        gpuPhysOffset[OUT]         - Physical offset of allocation returned only
                                     if contiguous allocation is requested. 
        bContiguousPhysAlloc[IN]   - Flag to request contiguous allocation. Default
                                     will follow the vidHeapControl default policy.
        bHandleProvided [IN]       - Flag to signify that the client has provided 
                                     the handle for phys allocation.
        hPhysHandle[IN/OUT]        - The handle will be used in allocation if provided.
                                     If not provided; allocator will return the handle
                                     it used eventually.
    Error codes:
        NV_ERR_INVALID_ARGUMENT  
        NV_ERR_NO_MEMORY              - Not enough physical memory to service
                                        allocation request with provided constraints
        NV_ERR_INSUFFICIENT_RESOURCES - Not enough available resources to satisfy allocation request
        NV_ERR_INVALID_OWNER          - Target memory not accessible by specified owner
        NV_ERR_NOT_SUPPORTED          - Operation not supported on broken FB
 
*/
NV_STATUS nvUvmInterfaceMemoryAllocGpuPa(uvmGpuAddressSpaceHandle vaSpace,
                                         NvLength length,
                                         UvmGpuPointer * gpuPointer,
                                         UvmGpuAllocInfo * allocInfo);
/*******************************************************************************
    nvUvmInterfaceMemoryAllocSys

    This function will allocate system memory and provide a mapped Gpu
    virtual address to this allocation.

    This function will allocate a minimum page size if the length provided is 0
    and will return a unique GPU virtual address.

    The default page size will be the small page size (as returned by query caps)
    The Alignment will also be enforced to small page size.

    Arguments:
        vaSpace[IN]          - Pointer to vaSpace object
        length [IN]          - Length of the allocation
        gpuPointer[OUT]      - GPU VA mapping
        allocInfo[IN/OUT]    - Pointer to allocation info structure which
                               contains below given fields
 
        allocInfo Members: 
        rangeBegin[IN]             - Allocation will be made between rangeBegin
        rangeEnd[IN]                 and rangeEnd(both inclusive). Default will be
                                     no-range limitation.
        gpuPhysOffset[OUT]         - Physical offset of allocation returned only
                                     if contiguous allocation is requested. 
        bContiguousPhysAlloc[IN]   - Flag to request contiguous allocation. Default
                                     will follow the vidHeapControl default policy.
        bHandleProvided [IN]       - Flag to signify that the client has provided 
                                     the handle for phys allocation.
        hPhysHandle[IN/OUT]        - The handle will be used in allocation if provided.
                                     If not provided; allocator will return the handle
                                     it used eventually.
    Error codes:
        NV_ERR_INVALID_ARGUMENT  
        NV_ERR_NO_MEMORY              - Not enough physical memory to service
                                        allocation request with provided constraints
        NV_ERR_INSUFFICIENT_RESOURCES - Not enough available resources to satisfy allocation request
        NV_ERR_INVALID_OWNER          - Target memory not accessible by specified owner
        NV_ERR_NOT_SUPPORTED          - Operation not supported
*/
NV_STATUS nvUvmInterfaceMemoryAllocSys(uvmGpuAddressSpaceHandle vaSpace,
                                       NvLength length,
                                       UvmGpuPointer * gpuPointer,
                                       UvmGpuAllocInfo * allocInfo);

/*******************************************************************************
    nvUvmInterfaceMemoryFree

    Free up a GPU allocation
*/

void nvUvmInterfaceMemoryFree(uvmGpuAddressSpaceHandle vaSpace,
                              UvmGpuPointer gpuPointer);

/*******************************************************************************
    nvUvmInterfaceMemoryFreeVa

    Free up a GPU VA allocation
*/

void nvUvmInterfaceMemoryFreeVa(uvmGpuAddressSpaceHandle vaSpace,
                              UvmGpuPointer gpuPointer);

/*******************************************************************************
    nvUvmInterfaceMemoryFreePa

    Free up a GPU PA allocation
*/

void nvUvmInterfaceMemoryFreePa(uvmGpuAddressSpaceHandle vaSpace,
                              UvmGpuPointer gpuPointer);


/*******************************************************************************
    nvUvmInterfaceMemoryCpuMap

    This function creates a CPU mapping to the provided GPU address.
    If the address is not the same as what is returned by the Alloc
    function, then the function will map it from the address provided.
    This offset will be relative to the gpu offset obtained from the
    memory alloc functions.

    Error codes:
      NV_ERR_GENERIC
      NV_ERR_NO_MEMORY
*/
NV_STATUS nvUvmInterfaceMemoryCpuMap(uvmGpuAddressSpaceHandle vaSpace,
                                     UvmGpuPointer gpuPointer,
                                     NvLength length, void **cpuPtr,
                                     NvU32 pageSize);

/*******************************************************************************
    uvmGpuMemoryCpuUnmap

    Unmaps the cpuPtr provided from the process virtual address space.
*/
void nvUvmInterfaceMemoryCpuUnMap(uvmGpuAddressSpaceHandle vaSpace,
                                  void *cpuPtr);

/*******************************************************************************
    nvUvmInterfaceChannelAllocate

    This function will allocate a channel

    UvmGpuChannelPointers: this structure will be filled out with channel
    get/put. The errorNotifier is filled out when the channel hits an RC error.

    Error codes:
      NV_ERR_GENERIC
      NV_ERR_NO_MEMORY
*/

NV_STATUS nvUvmInterfaceChannelAllocate(uvmGpuAddressSpaceHandle  vaSpace,
                                        uvmGpuChannelHandle *channel,
                                        UvmGpuChannelPointers * pointers);

void nvUvmInterfaceChannelDestroy(uvmGpuChannelHandle channel);



/*******************************************************************************
    nvUvmInterfaceChannelTranslateError

    Translates NvNotification::info32 to string
*/

const char* nvUvmInterfaceChannelTranslateError(unsigned info32);

/*******************************************************************************
    nvUvmInterfaceCopyEngineAllocate

    ceIndex should correspond to three possible indexes. 1,2 or N and
    this corresponds to the copy engines available on the gpu.
    ceIndex equal to 0 will return UVM_INVALID_ARGUMENTS.
    If a non existant CE index is used, then this API will fail.

    The copyEngineClassNumber is returned so that the user can
    find the right methods to use on his engine.

    Error codes:
      NV_ERR_GENERIC
      NV_ERR_NO_MEMORY
      UVM_INVALID_ARGUMENTS
*/
NV_STATUS nvUvmInterfaceCopyEngineAllocate(uvmGpuChannelHandle channel,
                                           unsigned indexStartingAtOne,
                                           unsigned * copyEngineClassNumber,
                                           uvmGpuCopyEngineHandle *copyEngine);

/*******************************************************************************
    nvUvmInterfaceQueryCaps

    Return capabilities for the provided GPU.
    If GPU does not exist, an error will be returned.

    Error codes:
      NV_ERR_GENERIC
      NV_ERR_NO_MEMORY
*/
NV_STATUS nvUvmInterfaceQueryCaps(uvmGpuAddressSpaceHandle vaSpace,
                                  UvmGpuCaps * caps);
/*******************************************************************************
    nvUvmInterfaceGetAttachedUuids

    Return 1. a list of UUIDS for all GPUs found.
           2. number of GPUs found.

    Error codes:
      NV_ERR_GENERIC
 */
NV_STATUS nvUvmInterfaceGetAttachedUuids(NvU8 *pUuidList, unsigned *numGpus);

/*******************************************************************************
    nvUvmInterfaceGetGpuInfo

    Return gpu architecture number & mode for the provided GPU uuid.
    If no gpu matching the uuid is found, an error will be returned.

    Error codes:
      NV_ERR_GENERIC
      NV_ERR_INSUFFICIENT_RESOURCES
 */
NV_STATUS nvUvmInterfaceGetGpuInfo(NvU8 *pUuid, unsigned uuidLength,
                                   UvmGpuInfo * pGpuInfo);

/*******************************************************************************
    nvUvmInterfaceGetUvmPrivRegion

    Return UVM privilege region start and length
 */
NV_STATUS nvUvmInterfaceGetUvmPrivRegion(NvU64 *pUvmPrivRegionStart,
                                         NvU64 *pUvmPrivRegionLength);

/*******************************************************************************
    nvUvmInterfaceServiceDeviceInterruptsRM

    Tells RM to service all pending interrupts. This is helpful in ECC error
    conditions when ECC error interrupt is set & error can be determined only
    after ECC notifier will be set or reset.

    Error codes:
      NV_ERR_GENERIC
      UVM_INVALID_ARGUMENTS
*/
NV_STATUS nvUvmInterfaceServiceDeviceInterruptsRM(uvmGpuChannelHandle channel);


/*******************************************************************************
    nvUvmInterfaceCheckEccErrorSlowpath

    Checks Double-Bit-Error counts thru RM using slow path(Priv-Read) If DBE is
    set in any unit bEccDbeSet will be set to NV_TRUE else NV_FALSE.

    Error codes:
      NV_ERR_GENERIC
      UVM_INVALID_ARGUMENTS
*/
NV_STATUS nvUvmInterfaceCheckEccErrorSlowpath(uvmGpuChannelHandle channel,
                                              NvBool *bEccDbeSet);

/*******************************************************************************
    nvUvmInterfaceKillChannel

    Stops a GPU channel from running, by invoking RC recovery on the channel.

    Error codes:
      NV_ERR_GENERIC
      UVM_INVALID_ARGUMENTS
*/
NV_STATUS nvUvmInterfaceKillChannel(uvmGpuChannelHandle channel);

/*******************************************************************************
    nvUvmInterfaceGetGmmuFmt

    Gets GMMU Page Table format.
 
    Arguments:
        vaSpace[IN]          - Pointer to vaSpace object
        pFmt   [OUT]         - Reference of targeted MMU FMT.
 
    Error codes:
      NV_ERR_GENERIC
      NV_ERR_INVALID_ARGUMENT
*/
NV_STATUS nvUvmInterfaceGetGmmuFmt(uvmGpuAddressSpaceHandle vaSpace,
                                   void **pFmt);

/*******************************************************************************
    nvUvmInterfaceDupAllocation

    Duplicate an allocation represented by a physical handle.
    Duplication means: the physical handle will be duplicated from src vaspace 
    to dst vaspace and a new mapping will be created in the dst vaspace.
 
    Arguments:
        hPhysHandle[IN]          - Handle representing the phys allocation.
        srcVaspace[IN]           - Pointer to source vaSpace object
        srcAddress[IN]           - Offset of the gpu mapping in source vaspace.
        dstVaspace[IN]           - Pointer to destination vaSpace object
        dstAddress[OUT]          - Offset of the gpu mapping in destination 
                                   vaspace.
        bPhysHandleValid[IN]     - Whether the client has provided the handle
                                   for source allocation.
                                   If True; hPhysHandle will be used.
                                   Else; ops will find out the handle using
                                   srcVaspace and srcAddress

    Error codes:
      NV_ERROR
      NV_ERR_INVALID_ARGUMENT
*/
NV_STATUS nvUvmInterfaceDupAllocation(NvHandle hPhysHandle,
                                      uvmGpuAddressSpaceHandle srcVaspace,
                                      NvU64 srcAddress,
                                      uvmGpuAddressSpaceHandle dstVaspace,
                                      NvU64 *dstAddress,
                                      NvBool bPhysHandleValid);

/*******************************************************************************
    nvUvmInterfaceFreeDupedAllocation

    Free the lallocation represented by the physical handle used to create the
    duped allocation.
 
    Arguments:
        vaspace[IN]              - Pointer to source vaSpace object
        hPhysHandle[IN]          - Handle representing the phys allocation.
        
    Error codes:
      NV_ERROR
      NV_ERR_INVALID_ARGUMENT
*/
NV_STATUS nvUvmInterfaceFreeDupedHandle(uvmGpuAddressSpaceHandle vaspace,
                                        NvHandle hPhysHandle);

/*******************************************************************************
    nvUvmInterfaceGetFbInfo

    Gets FB information from RM.
 
    Arguments:
        vaspace[IN]       - Pointer to source vaSpace object
        fbInfo [OUT]      - Pointer to FbInfo structure which contains
                            reservedHeapSize & heapSize
    Error codes:
      NV_ERROR
      NV_ERR_INVALID_ARGUMENT
*/
NV_STATUS nvUvmInterfaceGetFbInfo(uvmGpuAddressSpaceHandle vaSpace,
                                  UvmGpuFbInfo * fbInfo);

/*******************************************************************************
    nvUvmInterfaceGetGpuIds
        Get GPU deviceId and subdeviceId from RM. UVM maintains a global table 
        indexed by (device, subdevice) pair for easy lookup.

    Arguments:
        pUuid[IN]            - gpu uuid
        uuidLength[IN]       - length of gpu uuid
        pDeviceId[OUT]       - device Id used by RM for given gpu
        pSubdeviceId[OUT]    - sub-device Id used by RM for given gpu

    Error codes:
      NV_ERR_GENERIC
      NV_ERR_INVALID_ARGUMENT
*/
NV_STATUS nvUvmInterfaceGetGpuIds(NvU8 *pUuid, unsigned uuidLength,
    NvU32 *pDeviceId, NvU32 *pSubdeviceId);

/*******************************************************************************
    nvUvmInterfaceInitFaultInfo

    This function obtains fault buffer address, size and a few register mappings
 
    Arguments:
        vaspace[IN]       - Pointer to vaSpace object associated with the gpu
        pFaultInfo[OUT]   - information provided by RM for fault handling

    Error codes:
      NV_ERR_GENERIC
      NV_ERR_INVALID_ARGUMENT
*/
NV_STATUS nvUvmInterfaceInitFaultInfo(uvmGpuAddressSpaceHandle vaSpace,
    UvmGpuFaultInfo *pFaultInfo);

/*******************************************************************************
    nvUvmInterfaceDestroyFaultInfo

    This function obtains destroys unmaps the fault buffer and clears faultInfo
 
    Arguments:
        vaspace[IN]       - Pointer to vaSpace object associated with the gpu
        pFaultInfo[OUT]   - information provided by RM for fault handling

    Error codes:
      NV_ERR_GENERIC
      NV_ERR_INVALID_ARGUMENT
*/
NV_STATUS nvUvmInterfaceDestroyFaultInfo(uvmGpuAddressSpaceHandle vaSpace,
    UvmGpuFaultInfo *pFaultInfo);


//
// Called by the UVM driver to register operations with RM
//
NV_STATUS nvUvmInterfaceRegisterUvmCallbacks(
                                         struct UvmOpsUvmEvents *importedUvmOps);

NV_STATUS nvUvmInterfaceDeRegisterUvmOps(void);

//
// TODO: Find out if there is an RM call that returns this information.
// Meanwhile we will set this to 2 which is the case for the biggest GPUs:
//
#define MAX_NUM_COPY_ENGINES  2

#endif // _NV_UVM_INTERFACE_H_
