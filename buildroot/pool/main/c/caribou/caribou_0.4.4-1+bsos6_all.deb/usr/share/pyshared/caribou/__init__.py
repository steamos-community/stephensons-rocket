from i18n import _
APP_NAME=_("Caribou")
