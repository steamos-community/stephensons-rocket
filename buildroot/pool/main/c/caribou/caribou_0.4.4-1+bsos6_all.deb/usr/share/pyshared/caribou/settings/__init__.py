GSETTINGS_SCHEMA = "org.gnome.caribou"

from caribou_settings import CaribouSettings

AllSettings = [CaribouSettings]
