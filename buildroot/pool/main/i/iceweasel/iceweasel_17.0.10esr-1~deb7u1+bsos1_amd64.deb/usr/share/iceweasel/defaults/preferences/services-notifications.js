pref("services.notifications.serverURL", "https://notifications.mozilla.org/");
