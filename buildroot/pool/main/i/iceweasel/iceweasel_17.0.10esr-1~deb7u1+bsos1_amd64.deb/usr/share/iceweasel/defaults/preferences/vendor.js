//@line 2 "/usr/src/packages/BUILD/iceweasel-17.0.10esr/debian/vendor.js.in"
pref("general.useragent.compatMode.firefox", true);
//@line 4 "/usr/src/packages/BUILD/iceweasel-17.0.10esr/debian/vendor.js.in"
pref("distribution.searchplugins.defaultLocale", "en-US");
// Forbid application updates
lockPref("app.update.enabled", false);
